# EVERSTEAD Native 0.32 — Living Village

Native iOS branch of EVERSTEAD using SwiftUI + RealityKit.

## Purpose of this package

This is the first consolidation layer for the existing native RealityKit build.
It adds isolated simulation modules without replacing the working 3D world.

Included:
- `EversteadPathfinding.swift` — navigation primitives
- `EversteadLivingVillage.swift` — households, families foundation, needs, activities and production
- `EversteadNativeSave.swift` — native save envelope

## Important integration note

The authoritative existing files `GameModels.swift` and `Everstead3DWorld.swift` remain unchanged in this package.
They must be integrated against the exact current source before replacing them. This avoids destroying the already working RealityKit world.

Next integration step:
1. connect Villager IDs and building IDs to `EversteadResidentLife`
2. store route waypoints on villagers
3. route autonomous villagers via roads/bridge
4. expose household/work/production data in ContentView
5. connect simulation ticks to EversteadGame time speed

Repository target: `alinaproboscht/Everstead-native`
